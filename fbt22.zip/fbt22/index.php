<?
/*
FBT2.2 - Flippy's BitTorrent Tracker v2.2 (GPL)
flippy `at` ameritech `dot` net, modified by code `at` maven `dot` de
*/
require_once("common.php");

function getstat($file)
{
	$handle = fopen($file, "rb");
	flock($handle, LOCK_SH); # shared lock for reader
	$no_peers = intval(filesize($file) / 7);
	$x = fread($handle, $no_peers * 7);
	fclose($handle); # don't need unlock as fclose unlocks
	for($j=0;$j<$no_peers;$j++)
	{
		$t_peer_seed = join('', unpack("C", substr($x, $j * 7, 1)));
		if($t_peer_seed >= 128)
			$complete++;
		else
			$incomplete++;
	}
	return '<TR BGCOLOR="#FFFFFF"><TD><A HREF="./?info_hash=' . $file . '">' . $file . '</A></TD><TD ALIGN="RIGHT">' . number_format($complete) . '</TD><TD ALIGN="RIGHT">' . number_format($incomplete) . '</TD></TR>';
}


?>
<HTML>
<HEAD>
<TITLE>FBT2.2 - BitTorrent Tracker</TITLE>
<STYLE TYPE="text/css">
<!--
BODY, TD, TH {
        font-family: Verdana;
        font-size: 11px;
        color: #867C68;
}

A {
        text-decoration: none;
}

A:HOVER {
        color: #FF0000;
        text-decoration: underline;
}
-->
</STYLE>
</HEAD>
<BODY TEXT="#867C68" LINK="#800000" ALINK="#800000" VLINK="#800000">
<?
$info_hash = $_GET['info_hash'];

if($info_hash && strlen($info_hash) == 40 && file_exists($info_hash))
{
	$torrent_name = $info_hash . '.torrent';
	if(file_exists($torrent_name))
		echo '<TABLE ALIGN="CENTER" CELLSPACING="10" CELLPADDING="0" BORDER="0"><TR><TD ALIGN="CENTER"><A HREF="' . $torrent_name . '">' . $torrent_name . '</A></TD></TR></TABLE>';
	echo '<TABLE ALIGN="CENTER" WIDTH="400" CELLSPACING="1" CELLPADDING="2" BORDER="0" BGCOLOR="#867C68"><TR BGCOLOR="#EAE7E2"><TH WIDTH="30%">IP</TH><TH WIDTH="20%">Status</TH><TH WIDTH="20%">Port</TH><TH WIDTH="30%">Last Action</TH></TR>';
	$handle = fopen($info_hash, "rb");
	flock($handle, LOCK_SH);
	$no_peers = intval(filesize($info_hash) / 7);
	$x = fread($handle, $no_peers * 7);
	fclose($handle);
	$time = intval((time() % 7680) / 60);
	for($j=0;$j<$no_peers;$j++)
	{
		$ip = unpack("C*", substr($x, $j * 7 + 1, 4));
		$ip = $ip[1] . '.' . $ip[2] . '.' . $ip[3] . '.*';
		$port = join('', unpack("n*", substr($x, $j * 7 + 5, 2)));
		$t_peer_seed = join('', unpack("C", substr($x, $j * 7, 1)));
		if($t_peer_seed >= 128)
		{
			$what = '<FONT COLOR="#008000"><B>seeder</B></FONT>';
			$t_time = $time - ($t_peer_seed - 128);
		}
		else
		{
			$what = 'leecher';
			$t_time = $time - $t_peer_seed;
			
		}
		if ($t_time < 0)
			$t_time += 128;
		echo '<TR BGCOLOR="#FFFFFF"><TD>' . $ip . '</TD><TD ALIGN="CENTER">' . $what . '</TD><TD ALIGN="RIGHT">' . $port . '</TD><TD ALIGN="RIGHT">' . number_format($t_time) . ' min ago</TD></TR>';
	}
	echo '</TABLE>';
}
else
{
?><TABLE ALIGN="CENTER" WIDTH="400" CELLSPACING="1" CELLPADDING="2" BORDER="0" BGCOLOR="#867C68"><TR BGCOLOR="#EAE7E2"><TH WIDTH="80%">Hash</TH><TH WIDTH="10%">UL</TH><TH WIDTH="10%">DL</TH></TR><?
	$handle = opendir('.');
	while (false !== ($file = readdir($handle)))
	{
		if(strlen($file) == 40)
			echo getstat($file);
	}
	closedir($handle);
?></TABLE><?
}
?><TABLE ALIGN="CENTER" CELLSPACING="10" CELLPADDING="0" BORDER="0"><TR><TD ALIGN="CENTER">FBT2.2 (<A HREF="source.tar.bz2">GPL</A>)</TD></TR></TABLE>
</BODY>
</HTML>
