<?php
error_reporting(1);

function er($txt)
{
	die('d14:failure reason' . strlen($txt) . ':' . $txt . 'e');
}
?>
